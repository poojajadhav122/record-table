<!-- footer -->
<div class="footer">
	<div class="container">
		<div class="cl-lg-12">
			<p>Copyright &copy; 2018 SMS Free. All rights reserved</p>
		</div>
	</div>
</div>

<!-- <script src="js/bootstrap.min.js"></script> -->
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/project.js"></script>

</body>
</html>