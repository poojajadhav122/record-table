<?php
	require_once 'header.php';
?>
	<div class="mid_part">
		<div class="container">
			<div class="col-lg-6">
				<h1>Contact<span>Us</span></h1>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
				
				
			</div>
			<div class="col-lg-6">
				<img src="images/banner.png">
			</div>
				
		</div>
	</div>

<?php
	require_once 'footer.php';
?>