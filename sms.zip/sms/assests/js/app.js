
var app = angular.module("smsApp",[]);
//console.log(app)


app.run(function($rootScope,$http, $compile){
	$rootScope.getMessages = function(category){
		//alert(category);
		var data = {category: category};
		$http.post(sitepath+"/message/getMessages",data).then(function(res){
			console.log(res.data);
			var str = "<ul>";
			if(res.data.length>0){
				for($i = 0;$i<res.data.length;$i++){
					str += "<li ng-click='sendText($event)'>"+res.data[$i]['message']+"</li>";
				}
			}
			str+="</ul>";
			var $el = $(str).appendTo("#sms");
			$compile($el)($rootScope);
		})
		
	}

	$rootScope.sendText = function($event) {
		text = angular.element($event.target).html();
		$rootScope.message = text;
	}

	$rootScope.getContacts = function(g_id){
		//alert(category);
		var data = {g_id: g_id};
		$http.post(sitepath+"/contact/getContacts",data).then(function(res){
			console.log(res.data);
			var str = "<ul>";
			if(res.data.length>0){
				for($i = 0;$i<res.data.length;$i++){
					str += "<li ng-click='setContact($event)' data='"+res.data[$i]['con_mobile']+"-"+res.data[$i]['con_email']+"'>"+res.data[$i]['con_name']+"</li>";

				}
			}
			str+="</ul>";
			var el = $(str).appendTo("#contact");
			$compile(el)($rootScope);
		})
	}
	$rootScope.setContact = function($event) {
		$rootScope.con_name = angular.element($event.target).html();

		var data = angular.element($event.target).attr("data");
		var userData = data.split("-");
		$rootScope.con_mobile = userData[0];
		$rootScope.con_email = userData[1];
	}
	$rootScope.sendSms = function() {
		var data = {name:$rootScope.con_name, mobile:$rootScope.con_mobile, email: $rootScope.con_email, message:$rootScope.message};
		//console.log(data)
		$http.post(sitepath+"/sms/sendEmail", data).then(function(res){
			console.log(res);
		})
	}
});


app.controller("group",function($scope, $http)
{
	//console.log($scope)
	$scope.g_name = "Friends";
	$scope.addGroup = function() {
		var data = {g_name:$scope.g_name};
		//console.log(data)
		$http.post(sitepath+"/group/insertGroup",data).then(function(res){
			console.log(res.data);
			$scope.error = res.data;
		})
	}
})

app.controller("contact",function($scope, $http)
{
	//console.log($scope)
	
	$scope.contactSave = function() {
		$scope.error = "";
		var data = {con_group:$scope.con_group,con_name:$scope.con_name,con_mobile:$scope.con_mobile,con_email:$scope.con_email};
		//console.log(data)
		$http.post(sitepath+"/contact/insertContact",data).then(function(res){
			console.log(res.data);
			$scope.error = res.data;
		})
	}
})

app.controller("message",function($scope, $http)
{
	//console.log($scope)
	
	$scope.messageSave = function() {
		$scope.error = "";
		var data = {mes_category:$scope.mes_category,message:$scope.message};
		//console.log(data)
		$http.post(sitepath+"/message/insertMessage",data).then(function(res){
			console.log(res.data);
			$scope.error = res.data;
		})
	}
})