$(function(){
	$("#singUp").click(function(){
		var formdata = $("#singUpForm").serialize();


		$.ajax({
			type:"post",
			url:sitepath+"/home/signUp",
			data:formdata,
			success:function(res){
				if(res==1){
					//alert("login success");
					window.location.href=sitepath+"/home/login";

				}else{
					$(".error").html(res);

				}
			},error:function(err){
				console.log(err)
			}
		})
	})


	$("#singIn").click(function(){
		//alert("123");

		var user_name = $("#user_email").val();
		var user_pass = $("#user_pass").val();

		$.ajax({
			type:"post",
			url:sitepath+"/Home/singIn",
			data:{email: user_name,pass: user_pass},
			success:function(res){
				alert(res)
				if (res==1){
					window.location.href=sitepath+"/sms/index";
				}else{
					$(".error").html(res);
				}
			},error:function(err){
				console.log(err)
			}
		})


	})
	
})