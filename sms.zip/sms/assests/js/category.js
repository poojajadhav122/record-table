$(function(){
	$("#categoryBtn").click(function(){
		var ca_name = $("#ca_name").val();
		$.ajax({
			type:"post",
			url:sitepath+"/category/insertCategory",
			data:{ca_name:ca_name},
			success:function(res){
				$(".error").html(res);

			},error:function(err){
				console.log(err)
			}
		})
	})

})