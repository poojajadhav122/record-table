<?php

class Myclass
{
	 protected $CI = "";
	 function __construct()
	 {
	 	$this->CI = &get_instance();

	 }

	 public function dropdown($params, $table, $where, $name)
	 {
	 	$vars = explode(",", $params);
	 	$str = "<select ng-model='".$name."' id='".$name."'>";
	 	$str .= "<option> -- Please select--</option>";
	 	$this->CI->db->select($params);
	 	if (!empty($where)){
	 		$this->CI->db->where($where);
	 	}
	 	$data = $this->CI->db->get($table);
	 	if($data->result_id->num_rows>0){
	 		foreach($data->result_array() as $k => $v){
	 			$str .= "<option value='".$v[$vars[0]]."'>".$v[$vars[1]]."</option>";
	 		}
	 	}
	 	echo $str .="</select>";
	 }

	 public function getCategories()
	 {
	 	$this->CI->db->select("ca_id,ca_name");
	 	$data = $this->CI->db->get("category");
	 	//print_r($data);
	 	if($data->result_id->num_rows>0){
	 		foreach($data->result_array() as $k =>$v){
	 			echo '<li><a href="" ng-click="getMessages('.$v['ca_id'].')">'.$v['ca_name'].'</a></li>';
	 		}
	 	}

	 }

	 public function getGroups()
	 {
	 	$this->CI->db->select("g_id,g_name");
	 	$data = $this->CI->db->get("groups");
	 	//print_r($data);
	 	if($data->result_id->num_rows>0){
	 		foreach($data->result_array() as $k =>$v){
	 			echo '<li><a href="" ng-click="getContacts('.$v['g_id'].')">'.$v['g_name'].'</a></li>';
	 		}
	 	}

	 }
}
?>