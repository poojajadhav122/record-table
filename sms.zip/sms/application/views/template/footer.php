<div id="footer">
	<p>Copyright (c) 2011 Sitename.com. All rights reserved. Design by <a href="http://www.freecsstemplates.org/">FCT</a>.</p>
</div>
<?php
my_js(array("jquery","login","category","angular.min","app"));
?>
<!-- end #footer -->
</body>
</html>