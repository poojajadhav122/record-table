<div id="sidebar">
					<ul>
						
						<li>
							<h2>Categories</h2>
							<ul>
								<?php
								$this->myclass->getCategories();
								?>
							</ul>
						</li>
						<li>
							<h2>Groups</h2>
							<ul>
								<?php
								$this->myclass->getGroups();
								?>
							</ul>
						</li>
						
					</ul>
				</div>