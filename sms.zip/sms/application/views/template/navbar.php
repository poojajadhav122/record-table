<div id="menu">
		<ul>
			<li class="current_page_item"><a href="<?php echo site_url()?>/sms/index">Home</a></li>
			<?php
				$user_id = $this->session->userdata('user_id');
				
				if(isset($user_id) && !empty($user_id)):
			?>
			<li><a href="#">Add Library</a></li>
			<li><a href="<?php echo site_url()?>/category/add">Add Contact</a></li>
			<li><a href="<?php echo site_url()?>/group/add">Add Group</a></li>
			<li><a href="<?php echo site_url()?>/contact/add">Add Contact</a></li>
			<li><a href="<?php echo site_url()?>/message/add">Add Sms</a></li>
			<li><a href="<?php echo site_url()?>/sms/index">Send Sms</a></li>
			<li><a href="<?php echo site_url()?>/home/logout">Logout</a></li>
			<?php
		else:
			?>

			<li><a href="<?php echo site_url()?>/home/login">SignIn</a></li>
			<li><a href="<?php echo site_url()?>/home/index">Sign Up</a></li>
			<?php
			 endif;
			?>
		</ul>
	</div>