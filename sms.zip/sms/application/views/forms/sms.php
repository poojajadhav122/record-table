<div class="row" id="content">
	<div class="col-md-4">
		<form>
			<div class="form-group">
				<label for="pwd">Name:</label>
				<input type="text" class="form-control" ng-model="con_name" id="con_name">				
			</div>
			<div class="form-group">
				<label for="pwd">Mobile:</label>
				<input type="text" class="form-control" ng-model="con_mobile" id="con_mobile">				
			</div>
			<div class="form-group">
				<label for="pwd">Email:</label>
				<input type="text" class="form-control" ng-model="con_email" id="con_email">				
			</div>
			<div class="form-group">
				<label for="pwd">Message:</label>
				<textarea ng-model="message"></textarea>			
			</div>
			<button type="button" ng-click="sendSms()" class="btn btn-default">Save</button>
		</form>
	</div>
	<div class="col-md-4">
		<h2>Sms</h2>
		<div id="sms">
			
		</div>
	</div>
	<div class="col-md-4">
		<h2>Contacts</h2>
		<div id="contact">
			
		</div>
		
	</div>
</div>

