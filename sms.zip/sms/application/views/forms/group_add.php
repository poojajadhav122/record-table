
				<div id="content" ng-controller="group">
					<h1>Group Add</h1>
					<div class="error bg-danger">{{error}}</div>
					<form  id="groupForm">
  
  <div class="form-group">
    <label for="pwd">Name:</label>
    <input type="text" class="form-control" name="g_name" ng-model="g_name">
  </div>
  
  <!-- <div class="checkbox">
    <label><input type="checkbox"> Remember me</label>
  </div> -->
  <button type="button" ng-click="addGroup()" class="btn btn-default">Save</button>
</form>
					
					
					
					
				</div>
				<!-- end #content -->
				
			