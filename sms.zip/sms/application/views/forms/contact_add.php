<div ng-controller="contact" id="content">
	<h1>Contact Form</h1>
	<div class="error bg-danger">{{error}}</div>
	<form id="contactForm">
		<div class="form-group">
			<label for="pwd">Select Group</label>
			<?php
				$this->myclass->dropdown("g_id,g_name","groups","","con_group");
			?>
			
		</div>
		<div class="form-group">
			<label for="pwd">Name:</label>
			<input type="text" class="form-control" ng-model="con_name" id="con_name">			
		</div>
		<div class="form-group">
			<label for="pwd">Mobile:</label>
			<input type="text" class="form-control" ng-model="con_mobile" id="con_mobile">			
		</div>
		<div class="form-group">
			<label for="pwd">Email:</label>
			<input type="text" class="form-control" ng-model="con_email" id="con_email">			
		</div>

		<button type="button" ng_click="contactSave()" class="btn btn-default">Submit</button>
		
	</form>
</div>