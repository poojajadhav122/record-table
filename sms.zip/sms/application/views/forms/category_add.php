
				<div id="content">
					<h1>Category Add</h1>
					<div class="error bg-danger"></div>
					<form  id="catForm">
  
  <div class="form-group">
    <label for="pwd">Name:</label>
    <input type="text" class="form-control" name="ca_name" id="ca_name">
  </div>
  
  <!-- <div class="checkbox">
    <label><input type="checkbox"> Remember me</label>
  </div> -->
  <button type="button" id="categoryBtn" class="btn btn-default">Save</button>
</form>
					
					
					
					
				</div>
				<!-- end #content -->
				
			