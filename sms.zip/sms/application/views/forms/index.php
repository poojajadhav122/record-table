
				<div id="content">
					<h1>Sing Up</h1>
					<div class="error bg-danger"></div>
					<form  id="singUpForm">
  <div class="form-group">
    <label for="email">User name:</label>
    <input type="text" class="form-control" name="user_name" id="user_name">
  </div>
  <div class="form-group">
    <label for="pwd">Email address:</label>
    <input type="email" class="form-control" name="user_email" id="user_email">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" name="user_pass" id="user_pass">
  </div>
  <!-- <div class="checkbox">
    <label><input type="checkbox"> Remember me</label>
  </div> -->
  <button type="button" id="singUp" class="btn btn-default">Submit</button>
</form>
					
					
					
					
				</div>
				<!-- end #content -->
				
			