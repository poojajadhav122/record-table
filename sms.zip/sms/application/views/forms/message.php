<div ng-controller="message" id="content">
	<h1>Contact Form</h1>
	<div class="error bg-danger">{{error}}</div>
	<form id="contactForm">
		<div class="form-group">
			<label for="pwd">Select Group</label>
			<?php
				$this->myclass->dropdown("ca_id,ca_name","category","","mes_category");
			?>
			
		</div>
		<div class="form-group">
			<label for="pwd">Message:</label>
			<textarea ng-model="message"></textarea>			
		</div>
		

		<button type="button" ng-click="messageSave()" class="btn btn-default">Save</button>
		
	</form>
</div>