<?php
$this->load->view("template/header");
$this->load->view("template/navbar");
?>
<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
<?php
$this->load->view("forms/".$form);
$this->load->view("template/sidebar");
?>
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>
<?php

$this->load->view("template/footer");
?>