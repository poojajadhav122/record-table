<?php
function my_js($arr){
	if(!empty($arr)){
		foreach($arr as $key => $value){
			echo "<script src='".base_url()."assests/js/".$value.".js'></script>";
		}
	}
}
function chkAuth()
{
	// if(!isset($_SESSION['user_id']) && empty($_SESSION['user_id'])){
	// 	redirect(site_url()."/home/login");
	// }

	$CI =& get_instance();
	$user_id = $CI->session->userdata('user_id');
	if(!isset($user_id) && empty($user_id)){
		redirect(site_url()."/home/login");
	}
}

function chkBeforeAuth()
{
	$CI =& get_instance();
	$user_id = $CI->session->userdata('user_id');
	if(isset($user_id) && !empty($user_id)){
		redirect(site_url()."/sms/index");
	}
}
?>