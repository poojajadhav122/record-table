<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Group extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		chkAuth();
		$this->load->model("mgroup");
		//array("mcategory","sms")
	}

	public function add()
	{
		$formdata['form'] = "group_add";
		$this->load->view("template",$formdata);
	}

	public function insertGroup()
	{
		$_POST = (array) json_decode(file_get_contents("php://input"));

		$this->form_validation->set_rules('g_name','Group','required|min_length[3]|max_length[50]|is uniqu[category.ca_name]');

		if($this->form_validation->run()==false)
		{
			echo validation_errors();
		}
		else{
			$id = $this->mgroup->insertGroup();
			echo set_value("g_name")." Group inserted";
		}
	}


}

?>