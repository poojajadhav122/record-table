<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Message extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		chkAuth();
		$this->load->model("mmessage");
	}

	public function add()
	{
		$formdata['form'] = "message";
		$this->load->view("template",$formdata);
	}

	public function insertMessage()
	{
		$_POST = (array) json_decode(file_get_contents("php://input"));
		//print_r($_POST);
		$this->form_validation->set_rules('mes_category', 'Category', 'required');
		$this->form_validation->set_rules('message', 'Message', 'required');
		

		if ($this->form_validation->run() == false){
			echo validation_errors();
		} else {
			$id = $this->mmessage->insertMessage();
			echo set_value("message")."message inserted";
		}

	}

	public function getMessages(){
		echo json_encode($this->mmessage->getMessage());
	}
}
?>