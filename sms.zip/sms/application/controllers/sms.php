<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sms extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		chkAuth();
	}

	public function index()
	{
		$formdata['form'] = "sms";
		$this->load->view("template",$formdata);
	}

	public function sendSms()
	{
		$userData = (array) json_decode(file_get_contents("php://input"));
		//print_r($userData);
		// Authorisation details.
		$username = "bshree287@gmail.com";
		$hash = "13fa5b06bce84dd92f65c316faa12a40b31d2c833fbd069a6e7a85d9a7b82996";

		// Config variables. Consult http://api.textlocal.in/docs for more info.
		$test = "0";

		// Data for text message. This is the text message data.
		$sender = "TXTLCL"; // This is who the message appears to be from.
		$numbers = "918380998026"; // A single number or a comma-seperated list of numbers
		$message = $userData['message'];
		// 612 chars or less
		// A single number or a comma-seperated list of numbers
		$message = urlencode($message);
		$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
		$ch = curl_init('http://api.textlocal.in/send/?');
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch); // This is the result from the API
		curl_close($ch);
		//print_r($result);
	}

	public function sendEmail()
	{
		$userData = (array) json_decode(file_get_contents("php://input"));
		
		$this->load->library('email');

		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$config['mailtype'] = "html";

		$this->email->initialize($config);
		$this->email->from('info.krpo@gmail.com', 'Infinitech');
		$this->email->to($userData['email']);
		//$this->email->cc('another@another-example.com');
		//$this->email->bcc('them@their-example.com');
		$this->email->attach("assests/images/img03.jpg");

		$this->email->subject('Email Test');
		$this->email->message($userData['message']);

	    $res = $this->email->send();
	    if (!$res) {
	    	print_r($this->email->print_debugger());
	    }
	    echo "Email has been sent";
	}
}

?>