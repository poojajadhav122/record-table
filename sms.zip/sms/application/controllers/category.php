<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		chkAuth();
		$this->load->model("mcategory");
		//array("mcategory","sms")
	}

	public function add()
	{
		$formdata['form'] = "category_add";
		$this->load->view("template",$formdata);
	}

	public function insertCategory()
	{
		$this->form_validation->set_rules('ca_name','Category','required|min_length[3]|max_length[50]|is uniqu[category.ca_name]');

		if($this->form_validation->run()==false)
		{
			echo validation_errors();
		}
		else{
			$id = $this->mcategory->insertcategory();
			echo set_value("ca_name")." Category inserted";
		}
	}


}

?>