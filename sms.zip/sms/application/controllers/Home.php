<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct(){

		parent::__construct();
		$this->load->model("mregister");
	}

	
	public function index()
	{
		chkBeforeAuth();
		$formdata['form'] = "index";
		$this->load->view("template",$formdata);
	}


	public function signUp(){

		$data = $this->input->post();

		$this->form_validation->set_rules('user_name','Username','required|min_length[3]|max_length[10]|alpha_numeric_spaces');
		$this->form_validation->set_rules('user_pass','Password','required|min_length[4]|max_length[10]');
		$this->form_validation->set_rules('user_email','Username','required|valid_email');


		if($this->form_validation->run()==FALSE){
			echo validation_errors();
		} else{
			$this->mregister->singUp();
			echo 1;
		}

	}
	public function login(){
		chkBeforeAuth();
		$formdata['form'] = "login";
		$this->load->view("template",$formdata);
	}

	public function singIn(){
		$ans = $this->input->post();
		$this->form_validation->set_rules('pass','Password','required|min_length[4]|max_length[10]');
		$this->form_validation->set_rules('email','Email','required|valid_email');

		if($this->form_validation->run()==FALSE){
			echo validation_errors();
		} else{

			$userData = $this->mregister->getUserData();
			// echo "<pre>";
			// print_r($userData);
			if(!empty($userData)){
			if($userData[0]->user_pass==do_hash($ans['pass'])){
				$arr = array(
					"user_id"=>$userData[0]->user_id,
					"user_name"=>$userData[0]->user_name,
					"user_pass"=>$userData[0]->user_pass,
					"user_email"=>$userData[0]->user_email,
				);
				$this->session->set_userdata($arr);
				echo 1;
			}else{
				echo "Invalid password";
			}
			
		}else{
			echo "User Name Invalid";
		}

	}
}

public function logout()
{
	$arr = array(
		"user_id",
		"user_name",
		"user_email",
		"user_pass"

	);
	$this->session->unset_userdata($arr);
	$this->session->sess_destroy();
	//print_r($this->session->all_userdata());die;
	redirect(site_url()."/home/login");
}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */