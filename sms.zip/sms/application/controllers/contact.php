<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class contact extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		chkAuth();
		$this->load->model("mcontact");
	}

	public function add()
	{
		$formdata['form'] = "contact_add";
		$this->load->view("template",$formdata);
	}

	public function insertContact()
	{
		$_POST = (array) json_decode(file_get_contents("php://input"));
		//print_r($_POST);
		$this->form_validation->set_rules('con_name', 'Name', 'required|min_length[3]|max_length[50]');
		$this->form_validation->set_rules('con_email', 'Email', 'required');
		$this->form_validation->set_rules('con_mobile', 'Mobile', 'required|min_length[10]|max_length[12]');
		$this->form_validation->set_rules('con_group', 'Group', 'required');

		if ($this->form_validation->run() == false){
			echo validation_errors();
		} else {
			$id = $this->mcontact->insertContact();
			echo set_value("con_name")."contact inserted";
		}

	}

	public function getContacts(){
		echo json_encode($this->mcontact->getContacts());
	}
}
?>