<?php

class Mgroup extends CI_Model
{
	public function insertGroup()
	{
		$g_name = $_POST['g_name'];
		$this->db->insert("groups",array("g_name"=>$g_name));
		return $this->db->insert_id();
	}
}
?>