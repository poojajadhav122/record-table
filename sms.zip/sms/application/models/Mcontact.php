<?php

class Mcontact extends CI_Model {

	public function insertContact()
	{
		$this->db->insert("contacts",$_POST);
		return $this->db->insert_id();
	}

	public function getContacts()
	{
		$_POST = (array) json_decode(file_get_contents("php://input"));
		$id = $_POST['g_id'];
		return $this->db->get_where("contacts",array("con_group"=>$id))->result();
	}
}
?>