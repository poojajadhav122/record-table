<?php

class Mmessage extends CI_Model {

	public function insertMessage()
	{
		$this->db->insert("message",$_POST);
		return $this->db->insert_id();
	}

	public function getMessage()
	{
		$_POST = (array) json_decode(file_get_contents("php://input"));
		$id = $_POST['category'];
		return $this->db->get_where("message", array("mes_category"=>$id))->result();
	}
}
?>