<?php

class Mregister extends CI_Model
{
	public function singUp()
	{
		$data = $this->input->post();
		$data['user_pass'] = do_hash($data['user_pass']);
		$this->db->insert("user_master",$data);
		return $this->db->insert_id();
	}

	public function getUserData()
	{
		$ans = $this->input->post();
		$this->db->select("user_email,user_pass,user_id,user_name");
		$this->db->where("user_email",$ans['email']);
		$userData = $this->db->get("user_master")->result();
		return $userData;
	}
}
?>