<?php

class Mcategory extends CI_Model
{
	public function insertCategory()
	{
		$cat_name = $this->input->post('ca_name');
		$this->db->insert("category",array("ca_name"=>$cat_name));
		return $this->db->insert_id();
	}
}
?>